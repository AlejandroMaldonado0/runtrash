package com.example.runtrash

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
